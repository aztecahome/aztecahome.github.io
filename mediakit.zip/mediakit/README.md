The colors used by AZTECA's logo are #bbbb88 and black.

Please try to use these colors alone.

These colors are also acceptable (order from lightest to darkest):

- #FFFFE8
- #F2F2D9
- #D6D6AF
- #BBBB88
- #9F9F66
- #878749
- #6F6F2F
- #58581D
- #44440F
- #2F2F06

Please try to use out SVG logo wherever possible and refer to AZTECA in all caps.

At this time, we do not have guidelines for font except sans serif.
